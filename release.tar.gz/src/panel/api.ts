/**
 * Gozargah — authenticated panel JSON API.
 * All routes live under /{panelPath}/api/* and require an HMAC session
 * cookie except /login (throttled) and /status (used to detect auth state).
 */

import { Env, GzError, VERSION } from '../config';
import { EffectiveSettings } from '../settings';
import {
  addEvent, recentEvents, saveSettings, SettingsBlob, loadSettings, invalidateCache,
  consumeAiDiagnosticQuota, loadPathHealth, savePathHealth, loadProfileHealth, loadAdaptiveModel, loadNetworkState, saveProtocolPolicyState, loadProtocolPolicyState, loadAdaptiveGuardState, loadPolicySignalState, saveHealthSample, loadLatestPathSamples,
} from '../db/store';
import {
  createUser, deleteUser, GzUser, invalidateUsers, listUsers, updateUser, flushUsage,
} from '../db/users';
import {
  checkLoginGate, clearedCookie, ipHash, isAuthed, makeSessionToken, onLoginResult,
  requireAuth, sessionCookie, verifyPanelPassword,
} from '../auth';
import { buildLinks, subTokenFor, buildProtocolMatrix } from '../subscription';
import { qrSvg } from '../utils/qr';
import { logRing } from '../utils/log';
import { pbkdf2Hex, randomHex } from '../utils/crypto';
import { createDiagnostics } from '../ai/diagnostics';
import { decideResilience, updateObservation, localResilienceAdvice, PathObservation } from '../ai/resilience';
import { decideAdaptiveProfile } from '../ai/edge-brain';
import { buildAdaptiveProtocolPlan } from '../ai/protocol-controller';
import { assessHealth } from '../ai/predictive-mesh';
import { defaultEdgeLearner, learnerConfidence } from '../ai/edge-learner';
import { classifyFailureDomain, classifyNetworkCondition, normalizeFetchFailure } from '../ai/network-intelligence';

const JSON_CT = 'application/json; charset=utf-8';

function json(data: unknown, status = 200, extraHeaders?: Headers): Response {
  const h = extraHeaders ?? new Headers();
  h.set('content-type', JSON_CT);
  h.set('cache-control', 'no-store');
  return new Response(JSON.stringify(data), { status, headers: h });
}

function publicUser(u: GzUser): Record<string, unknown> {
  return {
    id: u.id, name: u.name, uuid: u.uuid, trojanPass: u.trojanPass,
    quotaBytes: u.quotaBytes, usedUp: u.usedUp, usedDown: u.usedDown,
    expiryAt: u.expiryAt, expiryDays: u.expiryDays, firstUsedAt: u.firstUsedAt,
    enabled: u.enabled, isAdmin: u.isAdmin,
    createdAt: u.createdAt, lastSeen: u.lastSeen,
  };
}

export async function handlePanelApi(
  request: Request,
  env: Env,
  eff: EffectiveSettings,
  action: string,
): Promise<Response> {
  const method = request.method;
  const db = env.GZ_DB;

  try {
    /* ---------------- public ---------------- */

    if (action === 'status' && method === 'GET') {
      return json({
        version: VERSION,
        dbOk: eff.dbOk,
        isDefaultPassword: eff.isDefaultPassword,
        host: new URL(request.url).hostname,
        logs: logRing.slice(-12),
      });
    }

    if (action === 'login' && method === 'POST') {
      const gate = await checkLoginGate(env, request);
      if (!gate.allowed) {
        await addEvent(db!, 'login_blocked', 'rate limit reached');
        return json({ error: 'too_many_attempts', attemptsLeft: 0 }, 429);
      }
      const body = (await request.json().catch(() => ({}))) as { password?: string };
      const ok = await verifyPanelPassword(eff, String(body.password ?? ''));
      await onLoginResult(env, request, ok);
      if (!ok) {
        if (db) await addEvent(db, 'login_failed', 'bad password');
        return json({ error: 'bad_password', attemptsLeft: gate.attemptsLeft - 1 }, 401);
      }
      if (db) await addEvent(db, 'login_ok', 'panel login');
      const token = await makeSessionToken(eff);
      return json({ ok: true }, 200, new Headers({ 'set-cookie': sessionCookie(token) }));
    }

    /* ---------------- authenticated ---------------- */

    if (action === 'logout' && method === 'POST') {
      return json({ ok: true }, 200, new Headers({ 'set-cookie': clearedCookie() }));
    }

    await requireAuth(request, eff);

    if (action === 'me' && method === 'GET') {
      return json({ ok: true, version: VERSION, dbOk: eff.dbOk, isDefaultPassword: eff.isDefaultPassword });
    }

    if (action === 'network/resilience' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const rows = await loadPathHealth(db);
      let learner = defaultEdgeLearner();
      const modelRow = await loadAdaptiveModel(db);
      if (modelRow) { try { learner = JSON.parse(modelRow.stateJson); } catch { /* safe default */ } }
      const decision = decideResilience(rows.map(r => ({ id:r.pathId, latencyMs:r.latencyMs, ok:r.ok, checkedAt:r.checkedAt, failures:r.failures, successes:r.successes, quarantineUntil:r.quarantineUntil, consecutiveFailures:r.consecutiveFailures, consecutiveSuccesses:r.consecutiveSuccesses, lastError:r.lastError })), Date.now(), learner);
      return json({ ok:true, decision, advice: localResilienceAdvice(decision, 'fa'), policy: { mode: decision.mode, selectedPath: decision.selectedPath, dynamicOrdering: true, aiOptional: true, localLearner: true } });
    }

    if (action === 'network/state' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const [state, paths, settings] = await Promise.all([loadNetworkState(db), loadPathHealth(db), loadSettings(db)]);
      const configuredPaths = settings?.proxyIPs ?? eff.proxyIPs;
      const samples = await loadLatestPathSamples(db, configuredPaths);
      const pathById = new Map(paths.map((row) => [row.pathId, row]));
      const sourceByKind = {
        path_tcp: 'WORKER_TCP',
        path_dial: 'WORKER_SOCKET_DIAL',
        path_https: 'WORKER_HTTPS_HEAD',
        path: 'WORKER_LEGACY_UNSPECIFIED',
      } as const;
      const observations = samples.map((sample) => {
        const row = pathById.get(sample.subjectId);
        return {
          pathId: sample.subjectId,
          source: sourceByKind[sample.kind],
          ok: sample.ok,
          checkedAt: sample.ts,
          latencyMs: sample.latencyMs,
          failures: row?.failures ?? 0,
          successes: row?.successes ?? 0,
          consecutiveFailures: row?.consecutiveFailures ?? 0,
          lastError: row?.checkedAt === sample.ts ? row.lastError : '',
        };
      });
      const sampledPaths = new Set(observations.map((row) => row.pathId));
      for (const row of paths) {
        if (configuredPaths.includes(row.pathId) && !sampledPaths.has(row.pathId) && row.checkedAt > 0) {
          observations.push({
            pathId: row.pathId,
            source: 'WORKER_LEGACY_UNSPECIFIED',
            ok: row.ok,
            checkedAt: row.checkedAt,
            latencyMs: row.latencyMs,
            failures: row.failures,
            successes: row.successes,
            consecutiveFailures: row.consecutiveFailures ?? 0,
            lastError: row.lastError ?? '',
          });
        }
      }
      const condition = classifyNetworkCondition(configuredPaths, observations);
      return json({
        ok: true,
        state,
        condition,
        source: 'configured Worker-egress path telemetry only',
        physicalUpstreamDisconnectionProven: false,
        dpiProven: false,
        interpretation: 'observational-signal-only',
      });
    }

    if (action === 'network/brain' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const row = await loadAdaptiveModel(db);
      let learner = defaultEdgeLearner();
      if (row) { try { learner = JSON.parse(row.stateJson); } catch { /* safe default */ } }
      return json({
        ok: true, version: learner.version, updates: learner.updates, updatedAt: learner.updatedAt,
        learnerConfidence: Math.round(learnerConfidence(learner) * 100) / 100,
        weights: learner.weights, bias: learner.bias,
        source: 'aggregate connection telemetry only',
      });
    }

    if (action === 'network/capabilities' && method === 'GET') {
      const matrix = buildProtocolMatrix(env, new URL(request.url).hostname);
      return json({ ok: true, matrix, generatedAt: Date.now() });
    }

    if (action === 'network/policy' && method === 'GET') {
      const matrix = buildProtocolMatrix(env, new URL(request.url).hostname);
      return json({ ok: true, policy: matrix.adaptivePolicy, origin: matrix.origin, limitations: {
        worker_native_tcp_inbound: false,
        worker_native_udp_inbound: false,
        udp_protocols_require_origin_engine: true,
      } });
    }

    if (action === 'network/autoplan' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const host = new URL(request.url).hostname;
      const matrix = buildProtocolMatrix(env, host);
      const [pathRows, profileRows, state] = await Promise.all([loadPathHealth(db), loadProfileHealth(db), loadNetworkState(db)]);
      let learner = defaultEdgeLearner();
      const modelRow = await loadAdaptiveModel(db);
      if (modelRow) { try { learner = JSON.parse(modelRow.stateJson); } catch { /* safe default */ } }
      const predictive = Object.fromEntries(profileRows.map((r) => [r.profileId, {
        sampleCount: r.successes + r.failures, reliability: (r.successes + r.failures) ? r.successes / (r.successes + r.failures) : 0.5,
        latencyEwma: r.latencyMs, latencyVolatility: r.volatility ?? 1, successSlope: 0, latencySlope: 0,
        drift: (r.drift ?? 'stable') as 'improving'|'stable'|'degrading', forecastSuccess: r.forecastSuccess ?? 0.5,
        confidence: Math.min(1, (r.successes + r.failures) / 12),
      }]));
      const plan = buildAdaptiveProtocolPlan({ profiles: matrix.adaptivePolicy.profiles, health: profileRows, predictive, networkState: state ? { state: state.state as 'healthy'|'degraded'|'recovery'|'no_healthy_path', quorum: state.quorum, healthy: 0, degraded: 0, quarantined: 0, unknown: 0, total: pathRows.length, failureRate: state.failureRate, confidence: state.confidence, anomalyScore: state.anomalyScore, signalClass: state.signalClass as import('../ai/network-state').NetworkSignalClass, selectedPath: state.selectedPath || null, reasonCodes: state.reasonCodes, generatedAt: state.updatedAt } : null, learner, limit: 10 });
      await saveProtocolPolicyState(db, { selectedProfile: plan.selected || '', fallbackLadder: plan.fallbackLadder, reasonCodes: plan.reasonCodes, diversity: plan.diversity, confidence: plan.confidence, mode: plan.mode, consensus: plan.consensus, signalAgreement: plan.signalAgreement, switchRisk: plan.switchRisk, fusionMode: plan.fusionMode, policyFingerprint: plan.policyFingerprint, updatedAt: plan.generatedAt });
      return json({ ok: true, plan, persisted: true, origin: matrix.origin, generatedAt: Date.now() });
    }

    if (action === 'network/policy-state' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      return json({ ok: true, state: await loadProtocolPolicyState(db) });
    }

    if (action === 'network/fusion' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const state = await loadPolicySignalState(db);
      let parsed: Record<string, unknown> | null = null;
      if (state) { try { parsed = JSON.parse(state.stateJson) as Record<string, unknown>; } catch { parsed = null; } }
      return json({ ok: true, state: state ? { ...(parsed || {}), updatedAt: state.updatedAt } : null, semantics: {
        payloadInspection: false,
        censorshipIdentityProven: false,
        purpose: 'multi-signal policy gating',
      } });
    }

    if (action === 'network/guard' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const state = await loadAdaptiveGuardState(db);
      return json({
        ok: true,
        state,
        semantics: {
          autonomous_promotion: true,
          canary_hold_ms: 900000,
          change_window_ms: 1800000,
          max_changes_per_window: 3,
          rollback_on_active_failure: true,
          packet_mutation: false,
          dpi_mechanism_claimed: false,
        },
      });
    }

    if (action === 'network/profiles' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const rows = await loadProfileHealth(db);
      const observations = rows.map(r => ({
        profileId: r.profileId as 'standard' | 'fragmented' | 'alt-port' | 'fragmented-alt',
        ok: r.ok, latencyMs: r.latencyMs, failures: r.failures, successes: r.successes,
        checkedAt: r.checkedAt, consecutiveFailures: r.consecutiveFailures,
        consecutiveSuccesses: r.consecutiveSuccesses, quarantineUntil: r.quarantineUntil,
      }));
      const decision = decideAdaptiveProfile(observations);
      return json({ ok: true, decision, learning: { persistent: true, source: 'connection-telemetry', deterministicFallback: true } });
    }

    if (action === 'network/forecast' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const rows = await loadProfileHealth(db);
      const forecast = rows.map((r) => ({
        profileId: r.profileId, drift: r.drift ?? 'stable', forecastSuccess: r.forecastSuccess ?? 0.5,
        volatility: r.volatility ?? 1, samples: r.successes + r.failures, checkedAt: r.checkedAt,
      })).sort((a,b) => b.forecastSuccess - a.forecastSuccess);
      return json({ ok: true, forecast, semantics: { predictive: true, payloadInspection: false, censorshipIdentityProven: false } });
    }

    if (action === 'network/probe' && method === 'POST') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const body = (await request.json().catch(() => ({}))) as { url?: unknown };
      const target = String(body.url ?? '').trim();
      if (!/^https:\/\//i.test(target) || target.length > 2048) throw new GzError('invalid probe url', 'validation');
      const parsed = new URL(target);
      const settings = await loadSettings(db);
      const allowed = new Set(settings?.proxyIPs ?? eff.proxyIPs);
      if (!allowed.has(parsed.hostname)) throw new GzError('probe target is not configured', 'validation');
      const started = Date.now();
      let ok = false;
      let lastError = '';
      let httpStatus: number | null = null;
      try {
        const response = await fetch(parsed.toString(), { method:'HEAD', redirect:'error', signal:AbortSignal.timeout(5000) });
        ok = response.ok;
        httpStatus = response.status;
        if (!ok) lastError = 'http_failure:' + response.status;
      } catch (error) {
        lastError = normalizeFetchFailure(error);
      }
      const latencyMs = Date.now() - started;
      const previous = (await loadPathHealth(db)).find(r => r.pathId === parsed.hostname);
      const next = updateObservation(previous ? { id:previous.pathId, latencyMs:previous.latencyMs, ok:previous.ok, checkedAt:previous.checkedAt, failures:previous.failures, successes:previous.successes, quarantineUntil:previous.quarantineUntil, consecutiveFailures:previous.consecutiveFailures, consecutiveSuccesses:previous.consecutiveSuccesses, lastError:previous.lastError } : undefined, ok, latencyMs, Date.now(), lastError);
      next.id = parsed.hostname;
      await saveHealthSample(db, { kind: 'path_https', subjectId: next.id, ts: next.checkedAt, ok, latencyMs });
      await savePathHealth(db, { pathId:next.id, latencyMs:next.latencyMs, ok:next.ok, failures:next.failures, successes:next.successes, quarantineUntil:next.quarantineUntil, checkedAt:next.checkedAt, consecutiveFailures:next.consecutiveFailures, consecutiveSuccesses:next.consecutiveSuccesses, lastError: ok ? '' : lastError });
      const decision = decideResilience(await loadPathHealth(db).then(rows => rows.map(r => ({ id:r.pathId, latencyMs:r.latencyMs, ok:r.ok, checkedAt:r.checkedAt, failures:r.failures, successes:r.successes, quarantineUntil:r.quarantineUntil, consecutiveFailures:r.consecutiveFailures, consecutiveSuccesses:r.consecutiveSuccesses, lastError:r.lastError }))));
      const failureDomain = ok ? null : classifyFailureDomain(lastError);
      await addEvent(db, 'network_probe', JSON.stringify({ host: parsed.hostname, ok, latencyMs, httpStatus, failureDomain }).slice(0, 1000));
      return json({ ok, latencyMs, httpStatus, failureDomain, decision, probeScope: 'HTTPS_HEAD_FROM_WORKER_EGRESS' });
    }

    if (action === 'ai/diagnostics' && method === 'POST') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const allowed = await consumeAiDiagnosticQuota(db, await ipHash(request));
      if (!allowed) return json({ error: 'ai_rate_limited' }, 429);
      const body = (await request.json().catch(() => ({}))) as { language?: unknown };
      const language = body.language === 'en' ? 'en' : 'fa';
      return json(await createDiagnostics(env, language));
    }

    if (action === 'settings' && method === 'GET') {
      const s = db ? await loadSettings(db) : null;
      return json({
        panelPath: s?.panelPath ?? eff.panelPath,
        subPath: s?.subPath ?? eff.subPath,
        proxyIPs: s?.proxyIPs ?? eff.proxyIPs,
        resetCycle: s?.resetCycle ?? eff.resetCycle ?? 'none',
        isDefaultPassword: s?.isDefaultPassword ?? eff.isDefaultPassword,
        dbOk: eff.dbOk,
      });
    }

    if (action === 'settings' && method === 'POST') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

      const next = await saveSettings(db, (prev) => {
        const cur: SettingsBlob = prev ?? {
          schemaVersion: 1, panelPath: eff.panelPath, subPath: eff.subPath,
          proxyIPs: eff.proxyIPs, resetCycle: 'none', passwordSalt: eff.passwordSalt, passwordHash: eff.passwordHash,
          pwIterations: eff.pwIterations, isDefaultPassword: eff.isDefaultPassword, createdAt: Date.now(),
        };
        const out: SettingsBlob = { ...cur };

        if (typeof body.panelPath === 'string') {
          const v = body.panelPath.trim().toLowerCase();
          if (!/^[a-z0-9][a-z0-9-]{2,31}$/.test(v)) throw new GzError('invalid panelPath', 'validation');
          out.panelPath = v;
        }
        if (typeof body.subPath === 'string') {
          const v = body.subPath.trim().toLowerCase();
          if (!/^[a-z0-9][a-z0-9-]{2,31}$/.test(v)) throw new GzError('invalid subPath', 'validation');
          out.subPath = v;
        }
        if (typeof body.resetCycle === 'string') {
          const v = body.resetCycle;
          if (v !== 'none' && v !== 'daily' && v !== 'weekly' && v !== 'monthly') {
            throw new GzError('invalid resetCycle', 'validation');
          }
          out.resetCycle = v;
        }
        if (Array.isArray(body.proxyIPs)) {
          const ips = (body.proxyIPs as unknown[])
            .map((x) => String(x).trim())
            .filter((x) => /^[a-z0-9.\-:]+$/i.test(x) && x.length <= 253);
          if (ips.length > 32) throw new GzError('too many proxyIPs', 'validation');
          out.proxyIPs = ips.length ? ips : ['proxyip.cmliussss.net'];
        }
        if (typeof body.newPassword === 'string' && body.newPassword.length > 0) {
          const pw = body.newPassword;
          if (pw.length < 8) throw new GzError('password too short (min 8)', 'validation');
          out.passwordSalt = randomHex(16);
          out.pwIterations = eff.pwIterations;
          // hash computed outside (async) — handled below
          (out as SettingsBlob & { __newPw?: string }).__newPw = pw;
        }
        return out;
      });

      // password hashing needs async — apply post-write if requested
      const marker = next as SettingsBlob & { __newPw?: string };
      if (marker.__newPw) {
        const pw = marker.__newPw;
        delete marker.__newPw;
        const salt = randomHex(16);
        const hash = await pbkdf2Hex(pw, salt, eff.pwIterations);
        marker.passwordSalt = salt;
        marker.passwordHash = hash;
        marker.isDefaultPassword = false;
        await saveSettings(db, () => marker);
        invalidateUsers();
        invalidateCache();
        await addEvent(db, 'password_changed', 'panel password updated');
      }
      invalidateCache();
      return json({ ok: true });
    }

    if (action === 'users' && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const users = await listUsers(db);
      const withTokens = [] as Array<Record<string, unknown>>;
      const host = new URL(request.url).hostname;
      for (const u of users) {
        withTokens.push({ ...publicUser(u), subToken: await subTokenFor(host, u.uuid) });
      }
      return json({ users: withTokens });
    }

    if (action === 'users' && method === 'POST') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
      const name = String(body.name ?? '').trim().slice(0, 32);
      if (!/^[\w\u0600-\u06FF .-]{1,32}$/.test(name)) throw new GzError('invalid name', 'validation');
      const quotaGB = Number(body.quotaGB ?? 0);
      if (!Number.isFinite(quotaGB) || quotaGB < 0 || quotaGB > 1024 * 100) throw new GzError('invalid quotaGB', 'validation');
      const expiryAt = Number(body.expiryAt ?? 0);
      if (!Number.isFinite(expiryAt) || expiryAt < 0) throw new GzError('invalid expiryAt', 'validation');
      const expiryDays = Number(body.expiryDays ?? 0);
      if (!Number.isFinite(expiryDays) || expiryDays < 0 || expiryDays > 3650) throw new GzError('invalid expiryDays', 'validation');
      const u = await createUser(db, { name, quotaBytes: Math.round(quotaGB * 1024 ** 3), expiryAt, expiryDays });
      await addEvent(db, 'user_created', name);
      return json({ user: publicUser(u) }, 201);
    }

    const userMatch = action.match(/^users\/(\d+)$/);
    if (userMatch) {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const id = Number(userMatch[1]);
      if (method === 'PATCH') {
        const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
        const patch: Record<string, unknown> = {};
        if (typeof body.name === 'string') {
          const n = body.name.trim().slice(0, 32);
          if (!/^[\w\u0600-\u06FF .-]{1,32}$/.test(n)) throw new GzError('invalid name', 'validation');
          patch.name = n;
        }
        if (body.quotaGB !== undefined) {
          const q = Number(body.quotaGB);
          if (!Number.isFinite(q) || q < 0) throw new GzError('invalid quotaGB', 'validation');
          patch.quotaBytes = Math.round(q * 1024 ** 3);
        }
        if (body.expiryAt !== undefined) {
          const x = Number(body.expiryAt);
          if (!Number.isFinite(x) || x < 0) throw new GzError('invalid expiryAt', 'validation');
          patch.expiryAt = x;
        }
        if (body.expiryDays !== undefined) {
          const d = Number(body.expiryDays);
          if (!Number.isFinite(d) || d < 0 || d > 3650) throw new GzError('invalid expiryDays', 'validation');
          patch.expiryDays = d;
          if (d > 0) patch.expiryAt = 0; // modes are mutually exclusive
        }
        if (body.enabled !== undefined) patch.enabled = !!body.enabled;
        if (body.resetUsage === true) { patch.resetUsage = true; patch.usedUp = 0; patch.usedDown = 0; }
        if (body.rotateCredentials === true) {
          const u = (await listUsers(db)).find((x) => x.id === id);
          if (u?.isAdmin) throw new GzError('cannot rotate admin credentials (reset D1 instead)', 'validation');
          patch.uuid = crypto.randomUUID();
          patch.trojanPass = randomHex(12);
        }
        await updateUser(db, id, patch);
        if (patch.usedUp !== undefined || patch.usedDown !== undefined) await flushUsage(db);
        await addEvent(db, 'user_updated', 'id=' + id);
        return json({ ok: true });
      }
      if (method === 'DELETE') {
        await deleteUser(db, id); // admin rows protected in SQL
        await addEvent(db, 'user_deleted', 'id=' + id);
        return json({ ok: true });
      }
    }

    const linksMatch = action.match(/^users\/(\d+)\/links$/);
    if (linksMatch && method === 'GET') {
      if (!db) throw new GzError('database_not_bound', 'no_db');
      const id = Number(linksMatch[1]);
      const u = (await listUsers(db)).find((x) => x.id === id);
      if (!u) throw new GzError('user not found', 'not_found');
      const host = new URL(request.url).hostname;
      const links = buildLinks(host, u, null);
      const tok = await subTokenFor(host, u.uuid);
      return json({
        links,
        subBase: 'https://' + host + '/' + eff.subPath + '/' + tok,
        subClash: 'https://' + host + '/' + eff.subPath + '/' + tok + '/clash',
        subSingbox: 'https://' + host + '/' + eff.subPath + '/' + tok + '/singbox',
        subXray: 'https://' + host + '/' + eff.subPath + '/' + tok + '/xray',
        subAdaptive: 'https://' + host + '/' + eff.subPath + '/' + tok + '/adaptive',
        statusPage: 'https://' + host + '/' + eff.subPath + '/' + tok,
      });
    }

    // on-demand QR (server-side generation — v1.2 removed the client CDN loader)
    if (action === 'qr' && method === 'GET') {
      const raw = new URL(request.url).searchParams.get('t') ?? '';
      let text = '';
      try { text = decodeURIComponent(escape(atob(raw.replace(/-/g, '+').replace(/_/g, '/')))); }
      catch { throw new GzError('invalid qr payload', 'validation'); }
      if (!text || text.length > 512) throw new GzError('invalid qr payload', 'validation');
      return json({ svg: await qrSvg(text, 230) });
    }

    if (action === 'events' && method === 'GET') {
      if (!db) return json({ events: [] });
      return json({ events: await recentEvents(db, 10) });
    }

    return json({ error: 'not_found' }, 404);
  } catch (e) {
    if (e instanceof GzError && e.code === 'unauthorized') {
      return json({ error: 'unauthorized' }, 401);
    }
    if (e instanceof GzError && e.code === 'validation') {
      return json({ error: e.message }, 400);
    }
    if (e instanceof GzError && e.code === 'no_db') {
      return json({ error: 'database_not_bound' }, 503);
    }
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
}

export async function checkIsAuthed(request: Request, eff: EffectiveSettings): Promise<boolean> {
  return isAuthed(request, eff);
}
